"# Solving-problems-using-the-Huffman-tree"

"Version 1:

A program that calculates the compression ratio. Compresses the string itself by creating a tree using the Huffman algorithm. Tasks from the computer science course 11th grade"

"Version 2:

1. Everything that includes version 1
2. The program now also draws the tree itself to you in the terminal"

To work with the second version, follow these conditions:
1) myvenv/Scripts/activate
2) pip install -r requirements.txt

"#002Corp"

"P.S:
If you get an error. Check if the treelib library is working for you. If not, then download it. 
Here is the command:
    pip install treelib"

"P.P.S:
If anything, I left the first version"
